use inc::Module::Install;

name 'MIME-Magic';
all_from 'lib/MIME/Magic.pm';

WriteAll;